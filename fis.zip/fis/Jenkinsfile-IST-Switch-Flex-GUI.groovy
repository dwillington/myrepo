pipeline {

    agent { label 'ISTGUI' }

    parameters {
        string(name: 'CODE_REPO', defaultValue: 'bitbucket.fis.dev/scm/emeaistgui/IST-Util.git', description: 'GUI code repository')
        string(name: 'ARTIFACTORY_SRVR', defaultValue: 'https://artifactory.fis.dev/artifactory', description: 'Artifactory server')
        string(name: 'ARTIFACTORY_REPO', defaultValue: 'emeaistgui-generic-dev', description: 'Artifactory repo')
    }

    stages {
        stage('Tool Setup') {
            steps {
                echo "CODE_REPO: ${params.CODE_REPO}"
                echo "ARTIFACTORY_SRVR: ${params.ARTIFACTORY_SRVR}"
                echo "ARTIFACTORY_REPO: ${params.ARTIFACTORY_REPO}"

				echo 'Cleaning up environment from prev build ...'
                //deleteDir()

				script {
                  	sh "which git"
                    sh "java -version"

                    rtServer (
                        id: 'artifactory-srvr',
                        url: "${params.ARTIFACTORY_SRVR}",
                        credentialsId: 'svcacct_istartifact'
                    )
                    //download tools
                    rtDownload (
                        serverId: 'artifactory-srvr',
                        spec: """{
                            "files":[
                                {
                                  "pattern": "${params.ARTIFACTORY_REPO}/istgui/jenkins/jasperreports-6.3.0-project-with-dependencies.tar.gz",
                                  "explode": true,
                                  "flat": true
                                },
                                {
                                  "pattern": "${params.ARTIFACTORY_REPO}/istgui/jenkins/ant.tar.gz",
                                  "flat": true
                                },
                                {
                                  "pattern": "${params.ARTIFACTORY_REPO}/istgui/jenkins/flex-sdk-4.6.0.tar.gz",
                                  "explode": true,
                                  "flat": true
                                }
                            ]
                        }"""
                    )

                    //Extend git credentials timeout
                    sh([script: 'git config --global credential.helper "cache --timeout 7200"'])
                    //sh([script: 'git config --global http.proxy http://proxy.fisdev.local:8080'])

                    //untar ant
                    sh "tar xf ant.tar.gz"
                    sh "./ant/bin/ant -version"

                    def releaseName = readFile "release-name.txt"
                    releaseName = releaseName.trim()
                    //checkout release file
                    dir("tmp/IST-Util") {
                        git url: "https://${params.CODE_REPO}", changelog: false, poll: false
                    }
                    sh "cp -f tmp/IST-Util/releases/${releaseName}.xml ."
                }
            }
		}

        stage('Build Setup') {
            steps{
                script{
                    def releaseName = readFile "release-name.txt"
                    releaseName = releaseName.trim()
                    def props = [ 
                        "release-file": "${releaseName}.xml",
                        PDIR: "${WORKSPACE}/pdir",
                        ANT_HOME: "${WORKSPACE}/ant",
                        FLEX_HOME: "${WORKSPACE}/flex-sdk-4.6.0",
                        JASPER_HOME: "${WORKSPACE}/jasperreports-6.3.0"
                    ]
                    def props_text = props.collect{entry->entry.key+"="+entry.value}.join('\n')
                    writeFile file: 'ant.properties', text: props_text
                }
            }
        }
        stage('Build Init'){
            steps{
                script {
                    sh "./ant/bin/ant -f c.xml make-release-json"
                    sh "cat release.json"
                    def releaseInfo = readJSON file: "release.json", returnPojo: true
                    releaseInfo.each { key, value -> 
                        echo "release info $key = $value"
                    }
                    def project_names = releaseInfo.projects*.name
                }
            }
        }
        stage('Delete all') {
            steps {
                script {
                    def releaseInfo = readJSON file: "release.json", returnPojo: true
                    def project_names = releaseInfo.projects*.name
                    project_names.each { val ->
                        echo "Deleting project: ${val}"
                        dir(val) {
                            deleteDir()
                        }
                    }
                    sh "pwd; ls"
                }
            }
        }
        stage('Fetch source'){
            steps {
                script {
                    def releaseInfo = readJSON file: "release.json", returnPojo: true
                    def urlBase = 'https://' + params.CODE_REPO.replaceFirst('/[^/]*$', '')
                    echo "urlBase = ${urlBase}"
                    releaseInfo.projects.each { project -> 
						checkout changelog: false, 
							poll: false, 
							scm: [
								$class: 'GitSCM',
								branches: [ [name: project.tag] ],
								extensions: [
									[ $class: 'CloneOption', depth: 1, honorRefspec: true, noTags: true, shallow: true ],
									[ $class: 'RelativeTargetDirectory', relativeTargetDir: project.name ]
								],
								userRemoteConfigs: [
									[
										refspec: "+refs/heads/${project.tag}:refs/remotes/origin/${project.tag}",
										url: "${urlBase}/${project.name}.git"
									]
								]
							]
                    }
                }
            }
        }
        stage('Fetch libraries') {
            steps {
                script {
                    def files = findFiles(glob: '**/*.ref')
                    echo "number of ref files: ${files.length}"

                    rtServer (
                        id: 'artifactory-srvr',
                        url: "${params.ARTIFACTORY_SRVR}",
                        credentialsId: 'svcacct_istartifact'
                    )
                    files.each { refFile ->
                        echo "processing refFile: ${refFile.name} ${refFile.path} ${refFile.directory} ${refFile.length} ${refFile.lastModified}"
                        def refFilePathAttributes = "${refFile.path}".tokenize("/")
                        def projName = refFilePathAttributes[0]

                        def refContent = readFile("${refFile.path}").tokenize("\r\n")

                        def i = "${refContent[1]}".indexOf("/legacy/")
                        def url = "${params.ARTIFACTORY_REPO}"+"${refContent[1]}".substring(i)
                        def downloadTarget = "${projName}"+"/${refContent[2]}"
                        echo "downloadTarget: ${downloadTarget}"

                        //download tools
                        rtDownload (
                            serverId: 'artifactory-srvr',
                            spec: """{
                                "files":[
                                    {
                                      "pattern": "${url}",
                                      "target": "${downloadTarget}",
                                      "flat": true
                                    }
                                ]
                            }"""
                        )
                    }
                }
            }
        }

        stage('Postprocess source') {
            steps {
                script {
                    sh "./ant/bin/ant -f c.xml postprocess-all-source"
                }
            }
        }
        stage('Build all'){
            steps {
                script {
                    sh """
                    cp IST-Common/manifest.xml .
                    cp IST-Common/c.xsl .
                    cp IST-Common/c2.xsl .
                    ./ant/bin/ant -f c.xml make-buildspec
                    """
                }
                script {
                    sh "./ant/bin/ant -f c.xml build-all"
                }
            }
        }
        stage('Zip up pdir') {
            steps {
                echo 'tar cvfz ./IST-Main/bin/pdir.tgz -C ${WORKSPACE}/pdir .'
                script{
                    def releaseName = readFile "release-name.txt"
                    releaseName = releaseName.trim()

                    sh "tar cvfz ./IST-Main/bin/pdir.tgz -C ${WORKSPACE}/pdir ."
                }
            }
        }

        stage('Test') {
            steps {
                echo 'No tests defined at this point'
            }
        }
        stage('Upload'){
            steps{
                script{
                    echo 'Uploading to artifactory ....'
                    def releaseName = readFile "release-name.txt"
                    releaseName = releaseName.trim()

                    rtServer (
                        id: 'artifactory-srvr',
                        url: "${params.ARTIFACTORY_SRVR}",
                        credentialsId: 'svcacct_istartifact'
                    )
                    rtUpload (
                        serverId: 'artifactory-srvr',
                        spec: """{
                            "files": [
                                {
                                  "pattern": "IST-Main/bin/IST-Switch.war",
                                  "target": "${params.ARTIFACTORY_REPO}/istgui/releases/IST-Switch-${releaseName}.war",
                                  "props": "type=war;status=ready"
                                },
                                {
                                  "pattern": "IST-Main/bin/pdir.tgz",
                                  "target": "${params.ARTIFACTORY_REPO}/istgui/releases/pdir-${releaseName}.tgz",
                                  "props": "type=tgz;status=ready"
                                }
                             ]
                        }"""
                    )
                }
            }
        }

        //********** uncomment following stage, if veracode upoad & scan to be part of one build **********
/*
       stage('Veracode Upload & Scan') {
            environment {
                SCAN_ID = "${BUILD_ID}"
            }
            withCredentials([usernamePassword(credentialsId: "veracode_api",usernameVariable: 'veracode_id', passwordVariable: 'veracode_key')]) {
                sh "java -jar /builds/jenkins/veracode-jenkins-plugin/VeracodeJavaAPI.jar \
                -action UploadAndScan -vid ${veracode_id} \
                -vkey ${veracode_key} -scantimeout 60 \
                -appname IST/SWITCH -createprofile false -criticality VeryHigh \
                -sandboxname ISTSwitch-JenkinsBuildFlexSandbox -createsandbox false \
                -version ${BUILD_ID} -autoscan true -filepath pdir.tgz"
            }
        }
	}
*/

    }
    post{
        always {
            archiveArtifacts artifacts: 'IST-Main/bin/pdir.tgz', onlyIfSuccessful: true
            echo 'artifact pdir.tgz archived.'
        }
    }
}