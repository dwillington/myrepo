pipeline {
	agent { label 'ISTGUI' }
	stages {
		stage('Setup') {
			environment {
				// BAMBUILD_CRED = credentials('cm-credentials-id')
				PAYFACNP_SVC_CRED = credentials('svcacct-payfacnp')
			}
			steps {
				sh './ist_setenv.ksh'
				// Download tools
				sh './ist_get_tools.ksh'
			}
		}
		
		stage('Build'){
			steps{
				script{
					echo 'Building....'
					sh "./ist_bld.ksh"
				}
			}
		}

		stage('TAR/Upload'){
		    environment {
				// BAMBUILD_CRED = credentials('cm-credentials-id')
				PAYFACNP_SVC_CRED = credentials('svcacct-payfacnp')
			}

			steps{
				script{
					echo 'Uploading....'
					sh "./ist_upload.ksh"
				}
			}
		}
	}
}