//----------------------------------------------------------------------
//----------------------------------------------------------------------
//----------------------------------------------------------------------
    // docker.image('alpine/git').inside() {
    // }
    // docker.image('docker').withRun('--rm -v /var/run/docker.sock:/var/run/docker.sock') {
      // sh "docker version"
    // }
  // docker.withServer('tcp://localhost:9080') {
  // }
//----------------------------------------------------------------------
node("ist-packer") {
  stage('Delete Images') {
    try {
      withCredentials([azureServicePrincipal(credentialsId: "IST_CLOUD_DP",
                      subscriptionIdVariable: 'SUBS_ID',

                      clientIdVariable: 'CLIENT_ID',
                      clientSecretVariable: 'CLIENT_SECRET',
                      tenantIdVariable: 'TENANT_ID')]) {
        sh 'az login --service-principal -u $CLIENT_ID -p $CLIENT_SECRET -t $TENANT_ID ; az account set -s $SUBS_ID'
        imagesToDelete = [

"DEVimgSW770_PV701551/15.0101.1",
"DEVimgSW770_PV701551/15.0101.11",
"DEVimgSW770_PV701551/15.0101.12",
"DEVimgSW770_PV701551/15.0101.13",
"DEVimgSW770_PV701551/15.0101.14",
"DEVimgSW770_PV701551/15.0101.15",
"DEVimgSW770_PV701551/15.0101.16",
"DEVimgSW770_PV701551/15.0101.17",
"DEVimgSW770_PV701551/15.0101.18",
"DEVimgSW770_PV701551/15.0101.2",
"DEVimgSW770_PV701551/15.0101.3",
"DEVimgSW770_PV701551/15.0101.4",
"DEVimgSW770_PV701551/15.0101.5",
"DEVimgSW770_PV701551/15.0101.6",
"DEVimgSW770_PV701551/15.0101.7",
"DEVimgSW770_PV701551/15.0101.9",
"DEVimgSW770_PV701551/16.0101.00",
"DEVimgSW770_PV701651/16.0101.00",
"DEVimgSW770_PV701651/16.0101.01",
"DEVimgSW770_PV701651/16.0101.02",

                         ]
        for (int i=0; i<imagesToDelete.size(); i++) {
          String[] aList = imagesToDelete[i].split('/');
          gallery_image_definition = aList[0];
          gallery_image_version = aList[1];
          sh "az sig image-version    delete --resource-group SHARED_IMAGE_GALLERY_USEAST2 --subscription $SUBS_ID --gallery-name fisdev_shared_image_gallery_useast2 --gallery-image-definition ${gallery_image_definition} --gallery-image-version ${gallery_image_version}"
        }
        // delete the image definition IF all versions are deleted?
        //sh "az sig image-version    delete --resource-group SHARED_IMAGE_GALLERY_USEAST2 --subscription $SUBS_ID --gallery-name fisdev_shared_image_gallery_useast2 --gallery-image-definition ${gallery_image_definition}"
      }
    }
    catch(Exception e) {
      println e
    }
  }
}
//----------------------------------------------------------------------
def imagesToDelete = ["DEVimgGUI770SP1504_04/15.04.04"]
for (int i=0; i<project_repo.size(); i++) {
  build job: 'delete resource', 
    parameters: [
        string(name: 'Resource_Type', value: "Image"),
        string(name: 'Resource_group_name', value: "SHARED_IMAGE_GALLERY_USEAST2"),
        string(name: 'ResourceName', value: "fisdev_shared_image_gallery_useast2/$imagesToDelete[i]"),
        string(name: 'ist-packer', value: "ist-packer")
    ]
}
//----------------------------------------------------------------------
node ('docker') {
  stage('Maven Build') {
    withCredentials([usernamePassword(credentialsId: 'svcacct_istartifact', usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD')]) {
      sh "docker login -u ${USERNAME} -p '${PASSWORD}' istsw-docker-snapshot-local.docker.fis.dev" 
      sh "docker pull istsw-docker-dev.docker.fis.dev/ubi7/ubi"
    }
  }
}
//----------------------------------------------------------------------
node ('ISTGUI') {

  jenkinsBuildURL = "${env.BUILD_URL}".replaceFirst('int-', '').replaceFirst(':8080', '')
  echo jenkinsBuildURL
  buildStatus = currentBuild.currentResult
  // Default values
  def subject = "JENKINS-NOTIFICATION: ${buildStatus}: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]'"
  def details = """<p>${buildStatus}: Job '${env.JOB_NAME} [${env.BUILD_NUMBER}]':</p>
  <p>Check console output at &QUOT;<a href='${jenkinsBuildURL}'>${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>&QUOT;</p>"""

  // Send email to user who has started the build
  emailext(
      subject: subject,
      body: details,
      // to: "Amjad.Ashraf@fisglobal.com",
     recipientProviders: [[$class: 'RequesterRecipientProvider'], [$class:'UpstreamComitterRecipientProvider']]
  )

}
//----------------------------------------------------------------------
node ('docker') {
  stage('Maven Build') {
    withDockerContainer(image: 'maven:latest', args: '') {
      withEnv(["JAVA_HOME=/usr/java/openjdk-14"]) {
        withMaven() {
          sh '$MVN_CMD --version > mvn-version.txt'
        }
      }
    }
    // withDockerContainer(image: "istsw-docker-snapshot-local.docker.fis.dev/db-installer-builder:latest", args: "-e BASH_ENV=bash_env") {
      // sh "ls -al /"
    // }
  }
}
//----------------------------------------------------------------------
node ('ISTGUI') {
  stage('Fetch source'){
    withCredentials([usernamePassword(credentialsId: 'svcacct_istartifact', usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD')]) {
        String encoded_password = java.net.URLEncoder.encode(env.PASSWORD, "UTF-8")
        sh "echo ${encoded_password}"
        // sh "api_key_encoded=\$(python -c \"import urllib, sys; print urllib.quote(sys.argv[1])\"  \"${PASSWORD}\")  echo \$api_key_encoded"
        sh "git clone https://${USERNAME}:${encoded_password}@bitbucket.fis.dev/scm/istfo/ist-switch-jenkins-pipeline-library.git"
    }
  }
}
        // sh "git clone https://${USERNAME}:${encoded_password}@bitbucket.fis.dev/scm/istfo/ist-switch-jenkins-pipeline-library.git"
    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'MyID', usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']]) {
        String encoded_password = java.net.URLEncoder.encode(env.GIT_PASSWORD, "UTF-8")
        sh("git tag -a some_tag -m 'Jenkins'")
        sh("git push https://${env.GIT_USERNAME}:${encoded_password}@<REPO> --tags")
    }
//----------------------------------------------------------------------
node ('ISTGUI') {
  stage('Fetch source'){

    def project_repo = ["istfo/ist-build-tools"]
 
    for (int i=0; i<project_repo.size(); i++) {
      checkout changelog: false, 
        poll: false, 
        scm: [
          $class: 'GitSCM',
          branches: [[name: '*/master']], 
          extensions: [
            [ $class: 'CloneOption', depth: 1, honorRefspec: true, noTags: true, shallow: true ],
            [ $class: 'RelativeTargetDirectory', relativeTargetDir: "${project_repo[i]}" ]
          ],
          userRemoteConfigs: [
            [credentialsId: 'svcacct_istartifact', url: "https://bitbucket.fis.dev/scm/${project_repo[i]}.git"]
          ]
        ]
    }
  }
}
//----------------------------------------------------------------------
node ('ISTGUI') {
  stage('git clone') {
    // git branch: 'master',
      // credentialsId: 'svcacct_istartifact',
      // url: 'https://bitbucket.fis.dev/scm/istfo/ist-switch-jenkins-pipeline-library.git'

    checkout changelog: false, 
      poll: false, 
      scm: [
        $class: 'GitSCM',
        branches: [[name: '*/master']], 
        extensions: [
          [ $class: 'CloneOption', depth: 1, honorRefspec: true, noTags: true, shallow: true ],
          [ $class: 'RelativeTargetDirectory', relativeTargetDir: "ist-build-tools" ]
        ],
        userRemoteConfigs: [
          [credentialsId: 'svcacct_istartifact', url: "https://bitbucket.fis.dev/scm/istfo/ist-build-tools.git"]
        ]
      ]
  }
}
//----------------------------------------------------------------------
"istfo/ist-build-tools", 
checkout([$class: 'GitSCM',
	  branches: [[name: '*/master']],
          userRemoteConfigs: [[url: "https://bitbucket.fis.dev/scm/istfo/ist-build-tools.git"]],
          extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: ""]]
          ])
//----------------------------------------------------------------------
      url: 'https://bitbucket.fis.dev/scm/istfo/fo_base.git'
      url: 'https://bitbucket.fis.dev/scm/istfo/ist-switch-jenkins-pipeline-library.git'
//----------------------------------------------------------------------
node ('docker') {
  stage('git clone') {
    withCredentials([usernamePassword(credentialsId: 'svcacct_istartifact', usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD')]) {
//        sh "echo '${PASSWORD}' > /tmp/toDelete2.txt"
        // sh '''
          // set +x
          // for (( i=0; i<${#PASSWORD}; i++ )); do
            // echo "${PASSWORD:$i:1}"
          // done
           // '''
        sh "curl -u $USERNAME:'$PASSWORD' https://artifactory.fis.dev/artifactory/emeaistswitch-generic-snapshot-local/rpm/"
        sh "curl -u $USERNAME:'$PASSWORD' -o oracle-instantclient12.2-basic-12.2.0.1.0-1.x86_64.rpm https://artifactory.fis.dev/artifactory/emeaistswitch-generic-snapshot-local/rpm/oracle-instantclient12.2-basic-12.2.0.1.0-1.x86_64.rpm"
        sh "ls -al"
    }
  }
}
#svcacct-istartifact
[testadmin@vlmazistbldbox ~]$ more /tmp/toDelete.txt
XcRJWdQ-\$8\&dyGrL
#svcacct_istartifact
[testadmin@vlmazistbldbox ~]$ more /tmp/toDelete2.txt
XcRJWdQ-$8&dyGrL
//----------------------------------------------------------------------
node ('ISTGUI') {
  ansiColor('xterm') {
    properties([buildDiscarder(logRotator(numToKeepStr: '5', artifactNumToKeepStr: '5'))])
    withDockerContainer(image: 'ist-gui-linux:latest', args: '-v /tmp/ist-build:/ist-build') {
      stage('Build all'){
          script {
              sh """
              cd /ist-build
              cp IST-Common/manifest.xml .
              cp IST-Common/c.xsl .
              cp IST-Common/c2.xsl .
              ./ant/bin/ant -f c.xml make-buildspec
              """
          }
          // script {
              // sh """
              // cd /ist-build
              // ./ant/bin/ant -f c.xml build-all
              // """
          // }
       }
    }
  }
}
//----------------------------------------------------------------------
node ('ISTGUI') {
  ansiColor('xterm') {
    properties([buildDiscarder(logRotator(numToKeepStr: '5', artifactNumToKeepStr: '5'))])
    stage('Build Setup') {
        script{
            def releaseName = readFile "release-name.txt"
            releaseName = releaseName.trim()
            def props = [ 
                "release-file": "${releaseName}.xml",
                PDIR: "/ist-build/pdir",
                ANT_HOME: "/ist-build/ant",
                FLEX_HOME: "/ist-build/flex-sdk-4.6.0",
                JASPER_HOME: "/ist-build/jasperreports-6.3.0"
            ]
            def props_text = props.collect{entry->entry.key+"="+entry.value}.join('\n')
            writeFile file: 'ant.properties', text: props_text
        }
    }
    stage('Build Init'){
        script {
            sh "./ant/bin/ant -f c.xml make-release-json"
            sh "cat release.json"
            def releaseInfo = readJSON file: "release.json", returnPojo: true
            releaseInfo.each { key, value -> 
                echo "release info $key = $value"
            }
            def project_names = releaseInfo.projects*.name
        }
    }
    stage('Postprocess source') {
        script {
            sh "./ant/bin/ant -f c.xml postprocess-all-source"
        }
    }
    withDockerContainer(image: 'ist-gui-linux:latest', args: '-v /tmp/ist-build:/ist-build') {
      stage('Build all'){
          script {
              sh """
              cd /ist-build
              cp IST-Common/manifest.xml .
              cp IST-Common/c.xsl .
              cp IST-Common/c2.xsl .
              ./ant/bin/ant -f c.xml make-buildspec
              """
          }
          script {
              sh """
              cd /ist-build
              ./ant/bin/ant -f c.xml build-all
              """
          }
       }
    }
  }
}
//----------------------------------------------------------------------
node ('ISTGUI') {
  properties([buildDiscarder(logRotator(numToKeepStr: '5', artifactNumToKeepStr: '5'))])
  stage('Fetch source') {
      script {
            checkout changelog: false, 
            poll: false, 
            scm: [
              $class: 'GitSCM',
              branches: [ [name: 'master'] ],
              extensions: [
                [ $class: 'CloneOption', depth: 1, honorRefspec: true, noTags: true, shallow: true ],
                [ $class: 'RelativeTargetDirectory', relativeTargetDir: 'IST-Util' ]
              ],
              userRemoteConfigs: [
                [
                  url: "https://bitbucket.fis.dev/scm/emeaistgui/IST-Util.git",
                  credentialsId: "cm-credentials-id"
                ]
              ]
            ]
      }
  }
}
//----------------------------------------------------------------------
node ('ISTGUI') {
  properties([buildDiscarder(logRotator(numToKeepStr: '5', artifactNumToKeepStr: '5'))])
  stage('Acceptance Test') {
    withDockerContainer(image: 'centos', args: '--privileged -v /usr/local/bin/kubectl:/usr/local/bin/kubectl') {
      withCredentials([file(credentialsId: 'k8s-config', variable: 'KUBECONFIG')]) {
        sh """
          kubectl proxy --address=0.0.0.0 --port=9080 &
          #sleep 2 # give kubectl proxy time to start
          curl -sS http://localhost:9080/api/v1/namespaces/default/services/http:hello-world-kubernetes:/proxy/
        """
      }
    }
  }
}
//----------------------------------------------------------------------
      if(env.BRANCH_NAME) { 
        // MULTI BRANCH PIPELINE, scm url, branch parameters are introspected
        // scmUrl = scm.userRemoteConfigs[0].url
        fullBranchName = env.BRANCH_NAME
      }

      if (fileExists('.git/config')) {
        // sh "cat .git/config"
        def branchName = sh(returnStdout: true, script: 'git rev-parse --abbrev-ref HEAD').trim()
        echo "branchName (via git rev-parse): " + branchName
        def scmUrl = sh(returnStdout: true, script: 'git config remote.origin.url').trim()
        scmName = scmUrl.split("/")[scmUrl.split("/").size()-1].replace(".git", "")		
      }

      echo "scmUrl: " + scmUrl
      echo "fullBranchName: " + fullBranchName
      echo "scmName: " + scmName
//----------------------------------------------------------------------
node ('ISTGUI') {
  stage('git clone') {
    git branch: 'master',
      credentialsId: 'lc5613593',
      url: 'ssh://git@sshbitbucket.fisdev.local:7999/~lc5613593/emeaist-pipeline-library.git'
  }
}
//----------------------------------------------------------------------
library identifier: 'emeaist-pipeline-library@master', retriever: legacySCM(
  [$class: 'GitSCM', 
    branches: [[name: '*/master']],
    userRemoteConfigs: [[credentialsId: 'lc5613593', url: 'ssh://git@10.7.215.23:7999/~lc5613593/emeaist-pipeline-library.git']]])

mainMethod('')
ssh://git@sshbitbucket.fisdev.local:7999/~lc5613593/istfo_test.git
//----------------------------------------------------------------------
        // sh "find -type f -name '*.ksh'  -exec sed -i -e 's/\\r\$//' {} \\;"
//----------------------------------------------------------------------
node ('ISTGUI') {
  stage('git clone') {
    git branch: 'master',
      credentialsId: 'cm-credentials-id',
      url: 'https://bitbucket.fis.dev/scm/ISTFO/istfo_test.git'
  }
}
//----------------------------------------------------------------------
node ('ISTGUI') {
  stage('git clone') {
    git branch: 'master',
      credentialsId: 'svcacct-istgui',
      url: 'https://bitbucket.fis.dev/scm/emeaistgui/ist-build.git'
  }
}
//----------------------------------------------------------------------
node ('ISTGUI') {
  stage('git clone') {
    git branch: 'master',
      credentialsId: 'svcacct-istgui',
      url: 'https://bitbucket.fis.dev/scm/emeaistgui/ist-build.git'
  }
  withEnv(["BASE_WORKSPACE=${env.WORKSPACE}"]) {
    load "Jenkinsfile"
  }
}

//----------------------------------------------------------------------
pipeline {
  agent { label 'ISTGUI' }
  stages {
    stage('Docker Login') {
      steps {
        withCredentials([usernamePassword(credentialsId: 'svcacct_istartifact', usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD')]) {
          script {
            def docker_url = "https://istsw-docker-snapshot-local.docker.fis.dev"
          }
          withDockerRegistry([url: docker_url, credentialsId: "svcacct_istartifact"]) {
            sh "docker login -u ${USERNAME} -p '${PASSWORD}' istsw-docker-snapshot-local.docker.fis.dev" 
          }
        }
      }
    }
    stage('Kubectl') {
      steps {
        configFileProvider(
          [configFile(fileId: 'k8s-config', variable: 'KUBECONFIG')]) {
          sh 'kubectl get pods -n dev2'
        }
      }
    }
  }
}
          // docker.withRegistry('https://artifactory.fis.dev', 'svcacct_istartifact') {
          // }
//----------------------------------------------------------------------


